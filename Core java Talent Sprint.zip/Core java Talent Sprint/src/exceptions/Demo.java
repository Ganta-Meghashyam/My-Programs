package exceptions;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers:");
		int n1 = 0, n2 = 0;

		try {
			n1 = sc.nextInt();// 2.3
			n2 = sc.nextInt();
			System.out.println(n1 / n2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// optional writing finally block
		finally {
			System.out.println("Remaining Code.....");
			System.out.println(n1 + n2);
			System.out.println(n1 - n2);
		}

	}

}
