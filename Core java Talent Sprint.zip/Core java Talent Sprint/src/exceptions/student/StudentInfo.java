package exceptions.student;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class StudentInfo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

		Student s1 = new Student("shyam", "kmm");
		Student s2 = new Student("megha", "kmm");
		Student s3 = new Student("ramana", "kmm");
		Student s4 = new Student("s", "kmm");
		Student s5 = new Student("h", "kmm");
		Student s6 = new Student("y", "kmm");
		Student s7 = new Student("a", "kmm");
		Student s8 = new Student("m", "kmm");
		Student s9 = new Student("as", "kmm");
		Student s10 = new Student("am", "kmm");

		Map<Integer,Student> StudentMap = new TreeMap<Integer,Student>();
		StudentMap.put(s1.getId(),s1);
		StudentMap.put(s2.getId(),s2);
		StudentMap.put(s3.getId(),s3);
		StudentMap.put(s4.getId(),s4);
		StudentMap.put(s5.getId(),s5);
		StudentMap.put(s6.getId(),s6);
		StudentMap.put(s7.getId(),s7);
		StudentMap.put(s8.getId(),s8);
		StudentMap.put(s9.getId(),s9);
		StudentMap.put(s10.getId(),s10);

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter id:");
		int id = sc.nextInt();

			if (StudentMap.containsKey(id)) {
				System.out.println(StudentMap.get(id));
			} else {
				try {
					throw new InvalidStudentException();
				} catch (InvalidStudentException i) {
					System.out.println("Student information not found");

				}
			}
			
			System.out.println("--------------------------------");
			//to print in file
			FileWriter writer = new FileWriter("StudentDetails");
			
			for(Map.Entry<Integer, Student> entry : StudentMap.entrySet()) {
				writer.write(entry.getKey() + ":" + entry.getValue()+"\n");
			}
			writer.close();
		}

	}


