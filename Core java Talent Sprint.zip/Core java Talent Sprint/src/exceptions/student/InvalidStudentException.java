package exceptions.student;

public class InvalidStudentException extends Exception{
	
	public InvalidStudentException() {
		super();
	}
	
	public InvalidStudentException(String s) {
		super(s);
	}

}
