package exceptions;

public class ThrowsDemo {
	
	private static void calculation(int n1 , int n2 , char option) throws Exception {
		
		switch(option) {
		
		case 'a': System.out.println(n1+n2);
		    break;
		    
		case 'd': System.out.println(n1/n2);
	           break;
	           
		case 's': System.out.println(n1-n2);
            break;
		
		default : System.out.println("wrong option");
	
		}
	}
	
	public static void main(String args[]) {
		
		int n1 = 6 , n2 = 0;
		char option = 'a';
		
		try {
		calculation(n1, n2, option);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
