package exceptions.UserDefined.customException;

import java.util.Scanner;

public class UserDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your num:");
		int num = sc.nextInt();
		
		if(num >= 0) {
			System.out.println(num +" is a positive number" );
		}
		else {
			throw new Exception("not found");
		}

	}

}
