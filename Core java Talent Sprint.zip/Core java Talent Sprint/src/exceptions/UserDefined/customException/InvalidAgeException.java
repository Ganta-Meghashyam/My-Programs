package exceptions.UserDefined.customException;

public class InvalidAgeException extends Exception {
	
	public InvalidAgeException() {
		super();
	}
	
	public InvalidAgeException(String s) {
		super(s);
	}
	
	

}
