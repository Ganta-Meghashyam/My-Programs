package exceptions.UserDefined.customException;

import java.util.Scanner;

public class AgeValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Age:");
		int age = sc.nextInt();
		
		if(age >= 18)
			System.out.println("Eligible for voting");
		else
			try {
				throw new InvalidAgeException();
			}catch(InvalidAgeException i) {
				System.out.println("Below 18 years,Not eligible for voting");
		
			}

	}

}
