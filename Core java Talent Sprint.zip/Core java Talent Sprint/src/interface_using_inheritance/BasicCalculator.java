package interface_using_inheritance;

public class BasicCalculator implements BasicCalc{

	private int val1 , val2;
	
	public int getVal1() {
		return val1;
	}

	public void setVal1(int val1) {
		this.val1 = val1;
	}

	public int getVal2() {
		return val2;
	}

	public void setVal2(int val2) {
		this.val2 = val2;
	}

	@Override
	public int addition() {
		// TODO Auto-generated method stub
		return val1+val2;
	}

	@Override
	public int subtraction() {
		// TODO Auto-generated method stub
		return val1-val2;
	}

	@Override
	public int multiplication() {
		// TODO Auto-generated method stub
		return val1*val2;
	}

}
