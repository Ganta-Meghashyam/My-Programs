package interface_using_inheritance;

public interface BasicCalc {
	
	public int addition();
	public int subtraction();
	public int multiplication();
	

}
