package interface_using_inheritance;

public interface ScientificCalc extends BasicCalc {
	
	public int squareRoot();
	public int matrices();
	int multiplication();
	

}
