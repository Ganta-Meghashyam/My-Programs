package interface_using_inheritance;

public class ScientificCalculator implements ScientificCalc {

	double val1 , val2;
	

	public double getVal1() {
		return val1;
	}

	public void setVal1(double val1) {
		this.val1 = val1;
	}

	public double getVal2() {
		return val2;
	}

	public void setVal2(double val2) {
		this.val2 = val2;
	}

	public ScientificCalculator(double val1, double val2) {
		super();
		this.val1 = val1;
		this.val2 = val2;
	}

	public ScientificCalculator() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int addition() {
		// TODO Auto-generated method stub
		
		return 0;
	}

	public int subtraction() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int multiplication() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int squareRoot() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int matrices() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
