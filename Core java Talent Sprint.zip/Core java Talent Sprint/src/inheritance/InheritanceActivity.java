package inheritance;

public class InheritanceActivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Traineee t = new Traineee(570 , "shyam" , "khammam ballepalli" , 832858317,4500);
		System.out.println(t);

	}

}
