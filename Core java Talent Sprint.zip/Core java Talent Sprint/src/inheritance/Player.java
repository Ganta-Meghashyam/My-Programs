package inheritance;

public class Player {

	private int id;
	String name;
	private static int idGenerator = 100;

	 

	public int getId() {
		return id;
	}

	
	public Player(int id, String Name) {
		this.id = id;
		this.name = Name;
	}

	
	public Player(String Name) {
		this.name = Name;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public void setId(int id) {
		this.id = id;
		id = idGenerator++;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + "]";
	}

}
