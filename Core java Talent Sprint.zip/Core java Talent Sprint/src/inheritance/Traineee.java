package inheritance;

public class Traineee extends Employee {

	public Traineee() {
	}

	public Traineee(long Id, String Name, String address, long phone,double basicSalary) {
		setEmployeeId(Id);
		setEmployeeName(Name);
		setEmployeeAddress(address);
		setPhone(phone);
		setBasicsalary(basicSalary);
	}

	@Override
	public double calculateSalary() {
		// TODO Auto-generated method stub
		return super.calculateSalary();
	}

	@Override
	public String toString() {
		return "Traineee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", phone=" + phone + ", basicsalary=" + basicsalary + ", specialAllowance="
				+ specialAllowance + ", Hra=" + Hra + ", calculateSalary()=" + calculateSalary() + "]";
	}
	
	

}
