package inheritance;

import java.text.DecimalFormat;

public class Bowler extends Player {

	private int ballsBowled;
	private int runsLeaked;
	private int wickets;
	
	
	
	public Bowler(String Name , int ballsBowled ,int runsLeaked , int wickets ) {
		
		super(Name);
		this.ballsBowled = ballsBowled;
		this.runsLeaked = runsLeaked;
		this.wickets = wickets;
	}
	
	public String getStrikeRate() {
		float strikerate = ballsBowled/wickets;
		DecimalFormat d = new DecimalFormat("0.##");
		return (d.format(strikerate));
	}

	@Override
	public String toString() {
		return "Bowler [Name=" + name + ", ballsBowled=" + ballsBowled + ", runsLeaked=" + runsLeaked + ", wickets=" + wickets + "]";
	}
	
	
}
