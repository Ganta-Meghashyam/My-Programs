package inheritance;

public class Cricket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Batsman b = new Batsman("Kohli" ,20000 , 70 ,50 , 2000 ,54 , 84);
		System.out.println(b);
		
		System.out.println("-------------------------------");
		
		Bowler bow = new Bowler("Bumrah" , 2500 , 1000 , 178);
		System.out.println(bow);

	}

}
