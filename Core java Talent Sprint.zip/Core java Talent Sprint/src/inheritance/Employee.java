package inheritance;

public class Employee {

	long employeeId;
	String employeeName;
	String employeeAddress;
	long phone;
	double basicsalary;
	double specialAllowance = 250.80;
	double Hra = 1000.50;

	public Employee() {

	}

	public Employee(long Id, String Name, String address, long phone) {
		employeeId = Id;
		employeeName = Name;
		employeeAddress = address;
		this.phone = phone;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	
	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	
	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	
	public double getBasicsalary() {
		return basicsalary;
	}

	public void setBasicsalary(double basicsalary) {
		this.basicsalary = basicsalary;
	}


	public double calculateSalary() {
		double salary = (basicsalary + (basicsalary * (specialAllowance / 100)) + (basicsalary * (Hra / 100)));
		return salary;
	}

}
