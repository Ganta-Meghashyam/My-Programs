package inheritance;

public class Manager extends Employee {

	public Manager() {
	}

	public Manager(long Id, String Name, String address, long phone , double basicSalary) {
		setEmployeeId(Id);
		setEmployeeName(Name);
		setEmployeeAddress(address);
		setPhone(phone);
		this.basicsalary = basicSalary;
	}
	@Override
	public double calculateSalary() {
		// TODO Auto-generated method stub
		return super.calculateSalary();
	}
}
