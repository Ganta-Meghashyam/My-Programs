package inheritance;

public class ScientificCalculator extends BasicCalculator {

	
	
	
	public ScientificCalculator() {

	}

	public ScientificCalculator(int value1, int value2) {
		setValue1(value1);
		setValue2(value2);
	}
	
	public double getSquareRoot() {
		return (Math.sqrt(getValue1()));
	}

	public double getPower() {
		return Math.pow(getValue1(), getValue2());
	}

	
	@Override
	public String toString() {
		return "ScientificCalculator [value1=" + getValue1() + ", value2=" + getValue2() + ", getSquareRoot()=" + getSquareRoot()
				+ ", getPower()=" + getPower() + ", getAddition()=" + getAddition() + ", getMultiplication()="
				+ getMultiplication() + "]";
	}
	
	

}
