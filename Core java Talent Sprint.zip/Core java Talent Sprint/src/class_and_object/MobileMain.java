package class_and_object;

public class MobileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mobile mi = new Mobile();
		mi.processor = "snapdrive";
		mi.os = "Android";
		mi.ram = 4;
		mi.battery = 4000;
		
	    mi.communication();
	    mi.entertainment();
	    
	    System.out.println("");
	    
	    System.out.println("processor:"+mi.processor);
	    System.out.println("os:"+mi.os);
	    System.out.println("ram:"+mi.ram);
	    System.out.println("battery:"+mi.battery);
	    
		

	}

}
