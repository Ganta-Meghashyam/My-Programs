package class_and_object;

public class Rectangle {

	float length;
	float breadth;

	double area() {
		return length * breadth;
	}

	double perimeter() {
		return (2 * (length + breadth));

	}
	
	public   String  toString() {
		return "length :" + length + "\n" + "Breadth:" + breadth + "\n"
	    + "Area:" +  area() + "\n" + "perimeter:" + perimeter(); 
	}

}
