package class_and_object;

public class StudentPercentage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student stu = new Student();
		stu.name = "Meghashyam";
		stu.id = 573;
		stu.biology = 90;
		stu.english = 87;
		stu.maths = 89;
		stu.physics = 100;
		stu.social = 98;
		
		System.out.println(stu.toString());
		System.out.println("---------------------------------");
		
		Student stu1 = new Student();
		stu1.name = "Shyam";
		stu1.id = 578;
		stu1.biology = 90;
		stu1.english = 95;
		stu1.maths = 100;
		stu1.physics = 79;
		stu1.social = 79;
		
		 System.out.println(stu1.toString());
       
	}

}
