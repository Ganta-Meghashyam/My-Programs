package class_and_object;

public class Mobile {
	String processor;
	String os;
	int ram;
	int battery;
	
	void communication() {
		System.out.println("calls");
	}
	void entertainment() {
		System.out.println("youtube");
	}
	
	

}
