package class_and_object;

public class Student {

	String name;
	int id;
	int english;
	int maths;
	int biology;
	int social;
	int physics;
	
	
	int total()
	{
		return english+maths+biology+social+social;
	}

	// each subject is for 100 marks so 5 subjects 5*100=500 total marks
	float percentage() {
		return ((float)(total()*100)/500);
	}

	public String toString() {
		return "Name : " + name + "\n" + "Id : " + id + "\n" + "Marks1 : " + english + "\n" + "Marks2 : " + maths + "\n"
				+ "Marks3 : " + biology + "\n" + "Marks4 : " + social + "\n" + "Marks5 : " + physics + "\n" + "percentage : "
				+ percentage();

	}

}
