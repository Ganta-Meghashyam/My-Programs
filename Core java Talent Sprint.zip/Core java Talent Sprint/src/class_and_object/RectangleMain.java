package class_and_object;

public class RectangleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rct = new Rectangle();
		rct.length = 2.7f;
		rct.breadth = 5.5f;

		System.out.println(rct.toString());


	}

}
