package constructor;

public class demomain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		demo d = new demo(5,3);
		System.out.println(d);
		

	}

}
