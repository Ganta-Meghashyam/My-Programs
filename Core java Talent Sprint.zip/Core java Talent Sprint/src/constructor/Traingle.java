package constructor;

public class Traingle {
	private int side1, side2, side3;

	public Traingle() {

	}

	public Traingle(int side1, int side2, int side3) {
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}

	public int getarea() {
		return (side1 + side2 + side3) / 2;
	}

	public int getperimeter() {
		return (side1 + side2 + side3);
	}

	public String toString() {
		return side1 + "\n" + side2 + "\n" + side3 + "\n" + "Area : " + getarea() + "\n" + "Perimeter : "
				+ getperimeter();
	}

}
