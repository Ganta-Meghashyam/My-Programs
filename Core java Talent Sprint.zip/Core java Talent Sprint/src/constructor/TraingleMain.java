package constructor;

public class TraingleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Traingle t = new Traingle(12, 13, 14);
		System.out.println(t);

	}

}
				