package constructor;

public class demo {
	int id, salary, name;
	
	public demo(int id, int name) {
		this.id = id;
		this.name = name;
	}

	public String toString() {
		return id + "\n" + salary + "\n" + name;
	}
}
