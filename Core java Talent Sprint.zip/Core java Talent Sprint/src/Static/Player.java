package Static;

import java.text.DecimalFormat;

public class Player {

	private int id;
	private String name;
	private int runsscored;
	private int centuries;
	private int halfcenturies;
	private int ballsfaced;
	private int sixes;
	private int fours;
	private static int idGenerator = 101;

	public Player() {
		id = idGenerator++; 
	}
	
	public int getId() {
		return id;
	}

	public Player(String name, int runsscored, int centuries, int halfcenturies, int ballsfaced, int sixes, int fours) {
		this();
		this.name = name;
		this.runsscored = runsscored;
		this.centuries = centuries;
		this.halfcenturies = halfcenturies;
		this.ballsfaced = ballsfaced;
		this.sixes = sixes;
		this.fours = fours;
	}						

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setRunScored(int runsscored) {
		this.runsscored = runsscored;
	}

	public int getRunsScored() {
		return runsscored;
	}

	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}

	public int getCenturies() {
		return centuries;
	}

	public void setHalfCentHuries(int halfcenturies) {
		this.halfcenturies = halfcenturies;
	}

	public int getHalfCenturies() {
		return halfcenturies;
	}

	public void setBallsFaced(int ballsfaced) {
		this.ballsfaced = ballsfaced;
	}

	public int getballsfaced() {
		return ballsfaced;
	}

	public void setSixes(int sixes) {
		this.sixes = sixes;
	}

	public int getSixes() {
		return sixes;
	}

	public void setFours(int fours) {
		this.fours = fours;
	}

	public int getFours() {
		return fours;
	}
	
	public float getStrikeRate() {
		float strikerate = (runsscored*100)/ballsfaced;
		DecimalFormat d = new DecimalFormat("0.##");
		return Float.parseFloat(d.format(strikerate));
	}
	
	public int getRunsScoredInBoundaries() {
		return(4 * fours + 6 * sixes);
	}
	
	
	
	public static Player getHighestStrikeRate(Player s1 , Player s2 ) {
		if(s1.getStrikeRate() > s2.getStrikeRate()) 
			return s1 ;
		else
			return s2;	
	}
	
	
	public String toString() {
		
		return "Id : " +id + "\n" + "Name : " + name + "\n" + "Runs Scored : " +runsscored+
				"\n" + "Centuries : " + centuries + "\n" + "Half Centuries : " +halfcenturies+
				"\n" + "BallsFaced : " +ballsfaced + "\n" + "Sixes : " + sixes +"\n"+"Fours : " +fours+ "\n"+
				"Strike Rate : " + getStrikeRate() +"\n"+ "Runs Scored In Boundary : " + getRunsScoredInBoundaries();
	  
	}

}
