package Static;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo D = new Demo();
		System.out.println(D);
        D.method();
        System.out.println(D);
        System.out.println("---------------");
        Demo d1 = new Demo();
        System.out.println(d1 );
        d1.method();
        System.out.println(d1);
	}

}
