package Static;

public class Demo {
	int x = 2;
	static int y = 3;
	
	void method() {
		x++;
		y++;
	}
	public String toString() {
		return "x = " +x  +"\n"+ "y = " +y;
	}
	

}
