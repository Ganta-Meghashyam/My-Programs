package Static;

public class Cricket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player p1 = new Player("Kohli",22450,72,103,30000,78,50);
		System.out.println("Id : " +p1.getId() + "\nStrike Rate : " +p1.getStrikeRate() + "\nRuns Scored in Boundaries : "+p1.getRunsScoredInBoundaries());
		
		System.out.println("----------------------------------------------------");
		Player p2 = new Player("Dhoni",19450,42,80,20000,68,40);
		System.out.println("Id : " +p2.getId() + "\nStrike Rate : " +p2.getStrikeRate() + "\nRuns Scored in Boundaries : "+p2.getRunsScoredInBoundaries());
		
		System.out.println("----------------------------------------------------");
		Player p3 = new Player("Rohit",18450,42,84,25000,70,43);
		System.out.println("Id : " +p3.getId() + "\nStrike Rate : " +p3.getStrikeRate() + "\nRuns Scored in Boundaries : "+p3.getRunsScoredInBoundaries());

		Player p = Player.getHighestStrikeRate(p1, p2);
		 p = Player.getHighestStrikeRate(p, p3);
		 
		 System.out.println("------------------------------------------------------------");
		 System.out.println(p);
		 
	}
	
}
