package interface_using_multiple_inheritance;

public interface Calc {
	
	public float strikeRate();

}
