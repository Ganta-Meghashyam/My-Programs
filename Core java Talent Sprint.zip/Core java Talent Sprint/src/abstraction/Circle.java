package abstraction;

public class Circle extends Shape {

	protected double radius;

	public Circle() {
	}

	public Circle(double radius, String color, boolean filled) {
		super(color, filled);
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	double getArea() {
		double Area = Math.PI * (radius * radius);
		return Area;
	}

	double getPerimeter() {
		double perimeter = 2 * (Math.PI) * (radius * radius);
		return perimeter;
	}

	public String toString() {
		return "Circle [radius=" + radius + ", color=" + color + ", filled=" + filled + ", Area()=" + getArea()
				+ ", Perimeter()=" + getPerimeter() + "]";
	}

}
