package abstraction;

public class PakistanCountry extends HeadOffice {
	
	public PakistanCountry() {
	}

	public PakistanCountry(String name) {
		super(name);
	}

	void ageValidation() {
		// TODO Auto-generated method stub
		System.out.println("Age Validation is done through bonafide ");
	}

	@Override
	void NationValidation() {
		// TODO Auto-generated method stub
		System.out.println("Nation Validation is done through Ration card");
	}

}



