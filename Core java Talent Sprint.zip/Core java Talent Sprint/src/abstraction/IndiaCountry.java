package abstraction;

public class IndiaCountry extends HeadOffice {

	public IndiaCountry() {
	}

	public IndiaCountry(String name) {
		super(name);
	}

	void ageValidation() {
		// TODO Auto-generated method stub
		System.out.println("Age Validation is done through DOB ");
	}

	@Override
	void NationValidation() {
		// TODO Auto-generated method stub
		System.out.println("Nation Validation is done through aadharcard");
	}

}
