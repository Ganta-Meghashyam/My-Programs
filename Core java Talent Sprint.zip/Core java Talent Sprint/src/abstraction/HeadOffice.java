package abstraction;

public abstract class HeadOffice {
	
	private String name;
	
	public HeadOffice() {	
	}
	
	public HeadOffice(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;	
	}
	
	abstract void ageValidation();
	abstract void NationValidation();
	
	}
	


