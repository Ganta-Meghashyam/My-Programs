package abstraction;

public class Square extends Rectangle {

	protected double side;

	public Square() {

	}

	public Square(double side) {
		this.side = side;
	}

	public Square(double side, String color, boolean filled) {

		setColor(color);
		setFilled(filled);
		this.side = side;
	}

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	double getArea() {
		double Area = side*side;
		return Area;
	}

	
	double getPerimeter() {
		double Perimeter = 4*side;
		return Perimeter;
	}

	@Override
	public String toString() {
		return "Square [side=" + side + ", color=" + color + ", filled=" + filled + ", Area()=" + getArea()
				+ ", Perimeter()=" + getPerimeter() + "]";
	}

}
