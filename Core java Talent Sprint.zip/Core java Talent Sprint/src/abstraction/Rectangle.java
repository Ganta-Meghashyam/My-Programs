package abstraction;

public class Rectangle extends Shape{

	protected double length;
	protected double width;
	
	public Rectangle() {
	}
	
	public Rectangle(double width , double length)
	{
		this.width = width;
		this.length = length;
	}
	
	public Rectangle(double width , double length , String color , boolean filled) {
		super(color , filled);
		this.width = width;
		this.length = length;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	
	double getArea() {
		double Area = length*width;
		return Area;
	}

	
	double getPerimeter() {
		double Perimeter = 2*(length+width);
		return Perimeter;
	}

	
	public String toString() {
		return "Rectangle [length=" + length + ", width=" + width + ", color=" + color + ", filled=" + filled
				+ ", Area()=" + getArea() + ", Perimeter()=" + getPerimeter() + "]";
	}
	
	
	
}
