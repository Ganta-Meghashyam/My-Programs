package abstraction;

public class ShapeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle(4, "Red" , true);
		System.out.println(c);
		
		System.out.println("-----------------------------------------------------------------------");
		
		Rectangle rec = new Rectangle(2,3);
		System.out.println(rec);
		
		Rectangle rec1 = new Rectangle(2,3,"pink",false);
		System.out.println(rec1);
		
		System.out.println("-------------------------------------------------------------------------");
		
		Square s = new Square(2);
		System.out.println(s);
		
		Square s1 = new Square(2,"blue",true);
		System.out.println(s1);

	}

}
