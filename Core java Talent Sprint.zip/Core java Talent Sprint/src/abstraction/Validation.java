package abstraction;

public class Validation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IndiaCountry India = new IndiaCountry();
		India.ageValidation();
		
		PakistanCountry Pakistan = new PakistanCountry();
		Pakistan.NationValidation();
		
	}

}
