package iterator;

import java.util.ArrayList;

import java.util.*;;

public class iteratorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> l1 = new ArrayList<Integer>();
		l1.add(23);
		l1.add(83);
		l1.add(33);
		l1.add(73);
		l1.add(63);
		
        Iterator<Integer> i1 = 	l1.iterator();
        
        /*
         * hasNext() -- check next element in the collection
         * next() -- current element
         * remove -- remove the current element
         */
        
        while (i1.hasNext()) {
        	System.out.println(i1.next());
        }
		

	}

}
