package iterator;

public class Book {
	
	private int id;
	private String author;
	private String publisher,name;
	private int cost;
	
	public Book(int id, String author, String publisher,String name, int cost) {
		super();
		this.id = id;
		this.author = author;
		this.publisher = publisher;
		this.name = name;
		this.cost = cost;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", author=" + author + ", publisher=" + publisher + ", name=" + name + ", cost="
				+ cost + "]";
	}
	

}
