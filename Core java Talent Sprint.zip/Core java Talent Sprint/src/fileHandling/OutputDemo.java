package fileHandling;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class OutputDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String data = "Solving today�s enterprise and industry challenges requires big data.";
			
		FileOutputStream output = new FileOutputStream("C:\\Users\\MEGHASHYAM GANTA\\OneDrive\\Desktop\\new.txt");
		
		byte[] content = data.getBytes();
		output.write(content);
		
		output.close();
		
		System.out.println("--------------------------------------------------------------");
		
		//files
		FileWriter writer = new FileWriter("output");
		writer.write(data);
		writer.close();
		

	}

}
