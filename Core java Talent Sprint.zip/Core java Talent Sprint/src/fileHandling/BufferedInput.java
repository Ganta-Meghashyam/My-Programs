package fileHandling;

import java.io.*;

public class BufferedInput {

	public static void main(String[] args) throws IOException {

		FileInputStream input = new FileInputStream("StudentDetails");
		BufferedInputStream buffer = new BufferedInputStream(input);

		int i = buffer.read();
		//System.out.println((char)i);

		
		
		FileReader reader = new FileReader("StudentDetails");
		BufferedReader bfreader = new BufferedReader(reader);

		// System.out.println((char)bfreader.read());

		String line = bfreader.readLine();

		
		while (line != null) {
			System.out.println(line);
			line = bfreader.readLine();
		}
	}

}
