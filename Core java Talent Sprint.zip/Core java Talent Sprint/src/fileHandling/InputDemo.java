package fileHandling;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class InputDemo {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		FileInputStream input = new FileInputStream("C:\\Users\\MEGHASHYAM GANTA\\OneDrive\\Desktop\\java programs.txt");
        int b = input.read();
        
        while(b != -1) {
        	System.out.print((char)b);
        	b=input.read();
        }
        input.close();
        
        System.out.println("------------------------------------------------------");
        
        //files
       /* FileReader reader = new FileReader("C:\\Users\\MEGHASHYAM GANTA\\OneDrive\\Desktop\\java programs.txt");
        int r = reader.read();
        
        while(r != -1) {
        	System.out.print((char)r);
        	r = reader.read();
        }*/
        
        
	}

}

