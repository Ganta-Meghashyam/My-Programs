package fileHandling;


import java.io.*;

public class ReadCSV {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\MEGHASHYAM GANTA\\OneDrive\\Desktop\\product.csv"));
		
		String line = reader.readLine();
		
		while(line != null) {
			System.out.println(line);
			line = reader.readLine();
		}

	}

}
