package filehandling_product;

public class Product {

	    int id,quantity;
	    float weight,price;
	    
	    public Product() {
			// TODO Auto-generated constructor stub
		}
	    
		public Product(int id, float weight, float price,int quantity) {
			super();
			this.id = id;
			this.quantity = quantity;
			this.weight = weight;
			this.price = price;
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public int getQuantity() {
			return quantity;
		}


		public void setQuantity(int quantity) {
			quantity = quantity;
		}


		public float getWeight() {
			return weight;
		}


		public void setWeight(float weight) {
			this.weight = weight;
		}


		public float getPrice() {
			return price;
		}


		public void setPrice(float price) {
			this.price = price;
		}


		@Override
		public String toString() {
			return "Product [id=" + id + ", Quantity=" + quantity + ", weight=" + weight + ", price=" + price + "]";
		}
	    
	    

	}


