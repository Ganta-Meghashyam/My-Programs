package filehandling_product;

import java.io.*;

public class Read_csv {
	
	public static Product createProduct(String line) {
		String [] data = line.split(",");
		int id = Integer.parseInt(data[0]);
		float weight = Float.parseFloat(data[1]);
		float price = Float.parseFloat(data[2]);
		int quantity = Integer.parseInt(data[3]);
		
		Product p = new Product(id,weight,price,quantity);
		
		return p;
		
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\MEGHASHYAM GANTA\\OneDrive\\Desktop\\product.csv"));
		
		String line = reader.readLine();
		
		line = reader.readLine();
		
		while(line != null) {
			Product p = createProduct(line);
			System.out.println(p);
			line = reader.readLine();
		}

	}

}
