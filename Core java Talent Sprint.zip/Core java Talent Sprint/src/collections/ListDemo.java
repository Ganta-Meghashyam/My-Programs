package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class ListDemo {

	public static void main(String[] ar) {
		// TODO Auto-generated method stub
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		l1.add(99);
		l1.add(25);
		l1.add(87);
		l1.add(67);
		l1.add(98);
//		Collections.sort(l1);
		
		
		
		System.out.println(l1);
		System.out.println(l1.get(2));
		
		l1.add(2 , 84);
		l1.add(1, 65);
//		l1.add(3, 45);
		
		System.out.println(l1);
		System.out.println(l1.subList(1, 4));
		
		LinkedList<Integer> l2 = new LinkedList<Integer>();
		l2.add(12);
		l2.add(54);
		l2.add(34);
		l2.add(76);
		System.out.println("-------------------------------");
		System.out.println(l2);
		
		l1.addAll(2,l2);
		System.out.println(l1);
		
		System.out.println("----------------------------");
		System.out.println("l1 : " +l1);
		System.out.println("l2 : " +l2);
		
		l2.addAll(2,l1);
		System.out.println(l2);
		
		Collections.sort(l1);
		System.out.println(l1);
		
		Collections.sort(l2);
		 System.out.println(l2);
		 
		 Collections.sort(l2 , Collections.reverseOrder());
		 System.out.println(l2);
		

	}

}
