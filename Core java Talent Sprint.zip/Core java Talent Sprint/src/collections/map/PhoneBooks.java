package collections.map;

public class PhoneBooks {
	
	String firstName;
	String Lastname;
	int phonenumber;
	
	public PhoneBooks() {
		// TODO Auto-generated constructor stub
	}
	
	public PhoneBooks(String firstName, String lastname, int phonenumber) {
		super();
		this.firstName = firstName;
		Lastname = lastname;
		this.phonenumber = phonenumber;
	}


	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	
	public String getLastname() {
		return Lastname;
	}
	
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	
	
	public int getPhonenumber() {
		return phonenumber;
	}
	
	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	@Override
	public String toString() {
		return "PhoneBooks [firstName=" + firstName + ", Lastname=" + Lastname + ", phonenumber=" + phonenumber + "]";
	}
	
	


}
