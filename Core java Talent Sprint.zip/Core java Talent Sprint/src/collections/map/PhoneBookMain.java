package collections.map;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PhoneBookMain {
	
	PhoneBooks p1 = new PhoneBooks("megha","shyam",987654);
	PhoneBooks p2 = new PhoneBooks("chowda","shyam",987654);
	PhoneBooks p3 = new PhoneBooks("megha","shyam",987654);
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashMap<String,Integer> phonebook = new HashMap<String,Integer>();
		
		for (Map.Entry<String, Integer> map : phonebook.entrySet()) {

			System.out.println(map);
		}
		

	}

}
