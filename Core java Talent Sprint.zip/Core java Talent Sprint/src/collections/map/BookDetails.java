package collections.map;

import java.util.*;

import java.util.Map.Entry;

public class BookDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b1 = new Book("shyam", "m", "shyam", 5884);
		Book b2 = new Book("megha", "s", "s", 1885);
		Book b3 = new Book("ramana", "v", "d", 4886);
		Book b4 = new Book("chowda", "j", "s", 2887);
		Book b5 = new Book("chowda", "j", "s", 3887);
		Book b6 = new Book("shyam", "m", "shyam", 5884);

		// key--->book-id && value------>book Object

		HashMap<Integer, Book> bookMap = new HashMap<Integer, Book>();
		bookMap.put(b1.getId(), b1);
		bookMap.put(b2.getId(), b2);
		bookMap.put(b3.getId(), b3);
		bookMap.put(b4.getId(), b4);
		bookMap.put(b5.getId(), b5);
		bookMap.put(b6.getId(), b6);

		// we can also use shortcut by using import java.util.entry;

		for (Map.Entry<Integer, Book> map : bookMap.entrySet()) {

			System.out.println(map);
		}

		System.out.println("---------------------------------------------");

		TreeMap<String, Integer> PublisherMap = new TreeMap<String, Integer>();
		
		//PublisherMap{m = 2 , s = 1 , v = 1 ,j = 2}
		

		for (Entry<Integer, Book> entry : bookMap.entrySet()) {

			Book b = entry.getValue();
			String publisher = b.getPublisher();

			if (PublisherMap.containsKey(publisher)) {
				int count = PublisherMap.get(publisher);
				count++;
				PublisherMap.put(publisher, count);
			} else
				PublisherMap.put(publisher, 1);

		}

		for (Entry<String, Integer> entry : PublisherMap.entrySet()) {

			System.out.println(entry);
		}

		System.out.println("-----------------------------------");

		for (Entry<String, Integer> entry : PublisherMap.entrySet()) {

			if (entry.getValue() > 1) {

				System.out.println(entry);
			}

		}

	}

}
