package collections.cab;

public class cabCustomerServiceTester {
	
	public static void main(String []args) {
		
	cabCustomer c1 = new cabCustomer(101 , "Shyam" , "lbnagar" , "gachibowli" , 4, 9889);
	cabCustomer c2 = new cabCustomer(102 , "Ramana" , "chaitanyapuri" , "gachibowli" , 5, 9889);
	
	cabCustomerService Service = new cabCustomerService();
	
	Service.addcabCustomer(c1);
	
	System.out.println(Service.printBill(c1));
	System.out.println(Service.printBill(c2));
	

}
}