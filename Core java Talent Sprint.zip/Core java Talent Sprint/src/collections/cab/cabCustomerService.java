package collections.cab;

import java.util.ArrayList;

public class cabCustomerService {
	
	private ArrayList<cabCustomer> CustomerList = new ArrayList<cabCustomer>();
	
	
	//getters and setters
	public ArrayList<cabCustomer> getCustomerList() {
		
		return CustomerList;
		
	}


	public void setCustomerList(ArrayList<cabCustomer> customerList) {
		
		CustomerList = customerList;
	
	}

	

	public void addcabCustomer(cabCustomer customer) {
		
		CustomerList.add(customer);
	
	}
	
	public boolean isFirstCustomer(cabCustomer customer) {
		
		for(cabCustomer customer1 : CustomerList) {
			
			if(customer1.getPhone() == customer.getPhone())
			
				return false;
		}
		
		return true;
		
	}
	
	public double calculateBill(cabCustomer customer) {
		
		if(isFirstCustomer(customer))
			return 0.0;
		
		else if(customer.getDistance() <= 4)
			return 80.0;
		
		else
			return 80 + ((customer.getDistance() - 4)*6);
	}
	
	
    public String printBill(cabCustomer customer) {//c1
		
		return customer.getCustomerName() + " please pay your bill of  "  + calculateBill(customer);
		
	}


	

	
	
	
	

}
