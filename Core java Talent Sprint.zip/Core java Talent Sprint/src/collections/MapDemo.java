package collections;

import java.util.*;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> maps = new HashMap<Integer,String>();
		maps.put(1, "Apple");
		maps.put(2, "Guava");
		maps.put(3, "orange");
		maps.put(4, "Grapes");
		
		System.out.println(maps);
		
		System.out.println("------------------------------");
		
		for(Map.Entry<Integer, String> entry : maps.entrySet()) {
			
			System.out.println(entry);
					
		}
		
		System.out.println("-----------------------------");
		
		for(Map.Entry<Integer, String> entry : maps.entrySet()) {
			
			System.out.println(entry.getValue());
		
		}
		
        System.out.println("-----------------------------");
		
		for(Map.Entry<Integer, String> entry : maps.entrySet()) {
		
			System.out.println(entry.getKey());
		
		}
		
		System.out.println("-------------------------------");
		System.out.println(maps.containsValue("Guava"));
		System.out.println(maps.containsKey(5));
		System.out.println(maps.keySet());
		System.out.println(maps.get(2));

		

	}

}
