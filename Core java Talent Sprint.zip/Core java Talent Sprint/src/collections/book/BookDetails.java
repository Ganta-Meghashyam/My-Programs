package collections.book;

import java.util.ArrayList;

import java.util.List;

import java.util.*;

public class BookDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b1 = new Book(573, "shyam", "m", "shyam", 5884);
		Book b2 = new Book(578, "megha", "s", "s", 1885);
		Book b3 = new Book(560, "ramana", "v", "d", 4886);
		Book b4 = new Book(570, "chowda", "j", "s", 2887);
		Book b5 = new Book(570, "chowda", "j", "s", 3887);

		List<Book> BookList = new ArrayList<Book>();
		BookList.add(b1);
		BookList.add(b2);
		BookList.add(b3);
		BookList.add(b4);
		BookList.add(b5);
		System.out.println(BookList);

		for (Book b : BookList) {
			System.out.println(b);
		}
		System.out.println("--------------------------------------------");

		// cost>3000
		for (Book b : BookList) {
			if (b.getCost() > 3000)
				System.out.println(b.getId() + "," + b.getname());
		}
		System.out.println("----------------------------------------");
		
		AuthorComparator a = new AuthorComparator();
		
		Collections.sort(BookList, new AuthorComparator());

		for (Book b : BookList) {
			System.out.println(b);

		}
		
		System.out.println("-------------------------------------");
		
		Collections.sort(BookList, new CostComparator());
		
		for (Book b : BookList) {
			System.out.println(b);

		}
		
		System.out.println("----------------------------------------------");
		
		
	}
}
