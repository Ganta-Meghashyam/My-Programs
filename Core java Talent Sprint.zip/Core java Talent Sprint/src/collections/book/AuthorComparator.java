package collections.book;

import java.util.Comparator;

public class AuthorComparator implements Comparator<Book>{

	public int compare(Book o1, Book o2) {
		// TODO Auto-generated method stub
		int i = o1.getAuthor().compareToIgnoreCase(o2.getAuthor());
		if(i<=-1)
			return 1;
		else if(i >= 1)
			return -1;
		
		return 0;
	}

	
	
	

}
