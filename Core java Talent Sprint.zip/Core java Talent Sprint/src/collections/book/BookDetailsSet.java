package collections.book;

import java.util.*;

public class BookDetailsSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Book> bookSet = new HashSet<Book>();
		bookSet.add(new Book(573, "shyam", "m", "shyam", 5884));
		bookSet.add(new Book(578, "megha", "s", "s", 1885));
		bookSet.add(new Book(560, "ramana", "v", "d", 4886));
		bookSet.add(new Book(570, "chowda", "j", "s", 2887));
		bookSet.add(new Book(570, "chowda", "j", "s", 3887));

		for (Book b : bookSet) {
			System.out.println(b);
		}

		System.out.println("----------------------------------------------");

		Set<Book> treeSetBook = new TreeSet<Book>(new AuthorComparator());
		treeSetBook.addAll(bookSet);

		for (Book b : treeSetBook)
			System.out.println(b);
		
		System.out.println("-------------------------------------------");
		
		Set<Book> setBook = new TreeSet<Book>(new CostComparator());
		setBook.addAll(bookSet);

		for (Book b : setBook)
			System.out.println(b);

	}

}
