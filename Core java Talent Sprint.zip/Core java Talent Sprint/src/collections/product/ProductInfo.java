package collections.product;

import java.util.*;

public class ProductInfo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Product> productList = new ArrayList<Product>();
		productList.add(new Product(78.2f, 500.9f));
		productList.add(new Product(79.8f, 5000f));
		productList.add(new Product(79.2f, 400f));
		productList.add(new Product(82.9f, 2500f));

		for (Product p : productList)
			System.out.println(p);

		System.out.println("------------------------------------");

		/*
		 * we can directly write code in product class using comparable but we can use
		 * that only once we cannot use for multiple variables(if you have doubt go and
		 * check in product class)
		 */

		Collections.sort(productList);

		for (Product p : productList)
			System.out.println(p);

		System.out.println("------------------------------------------------");

		/*
		 * if we want to use for multiple variables then you want to create seperate
		 * classes for all using comparator
		 */

		WeightComparator w = new WeightComparator();
		Collections.sort(productList, w);

		for (Product p : productList)
			System.out.println(p);

		System.out.println("------------------------------------------------");
		
		/*we can directly use productlist variables to productset only by using treeset in sets
		 * but we can use in for both lists (linked or array)
		 */

		Set<Product> productSet = new TreeSet<Product>();
		productSet.addAll(productList);

		for (Product p : productList)
			System.out.println(p);
		
		
		
	    getDuplicateCostProducts(productList);

	}
	
	public static void getDuplicateCostProducts(List<Product> productList) {
		
		System.out.println("-------------------------------");
		
		for(Product p1 : productList) {
			int count  =  0;
			for(Product p2 : productList) {
				if(p1.getPrice() == p2.getPrice()) {
					count++;
				}
			}
			if(count >= 2)
				System.out.println(p1);
		}
	}

}
