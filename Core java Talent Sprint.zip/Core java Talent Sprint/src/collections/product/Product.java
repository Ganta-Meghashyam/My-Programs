package collections.product;

public class Product implements Comparable<Product> {
	
	private int id;
	private float weight,price;
	private static int idGenerator=1;
	

	public Product() {
		id = idGenerator++;
	}
	
	public Product(float weight, float price) {
		this();
		this.weight = weight;
		this.price = price;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", weight=" + weight + ", price=" + price + "]";
	}

	@Override
	public int compareTo(Product o) {
		if(weight > o.getWeight())
			return -1;
		else if(weight < o.getWeight())
			return 1;
		
		
	return 0;
	}
	

}
