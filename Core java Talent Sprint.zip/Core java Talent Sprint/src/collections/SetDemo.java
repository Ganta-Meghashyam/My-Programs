package collections;

import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String args[]) {
		// unordered data
		HashSet<Integer> s1 = new HashSet<Integer>();
		s1.add(23);
		s1.add(450);
		s1.add(78);
		s1.add(78);

		System.out.println(s1);

		// Ascending order
		TreeSet<Integer> t1 = new TreeSet<Integer>();
		t1.add(45);
		t1.add(23);
		t1.add(67);
		t1.add(67);

		System.out.println(t1);

	}
}
