package filehandling_point;

import java.io.*;

import java.util.*;

import filehandling_product.Product;

public class PointInfo {
	
	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		DistanceCalculation cal = new DistanceCalculation();
		cal.readCSV("point.csv");

}

}
