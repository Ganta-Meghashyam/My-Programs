package filehandling_point;

import java.util.Comparator;
import java.util.Map;

public class DistanceComparator implements Comparator<String> {
	
	private Map<String, Double> distanceList;


	public DistanceComparator(Map<String,Double> distanceList) {
		super();
		this.distanceList = distanceList;		
	}
	
	
	public int compare(String arg0 ,String arg1) {
		double value1 = distanceList.get(arg0);
		double value2 = distanceList.get(arg1);
		
		if(value1 > value2)
			return -1;
		else
			return 1;
	}
	
}


