package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JDBCRunTimeInputs {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/c02", "root", "Meghashyam@73");
		Statement stmt = connect.createStatement();

		/*
		 * String query =
		 * "create table cabcustomer(custId int,custName varchar(25),pickuplocation varchar(25),droplocation varchar(25),distance int, phone long)";
		 *  stmt.execute(query);
		 * 
		 * String query =
		 * "insert into cabcustomer(custId,custName,pickuplocation,droplocation,distance, phone)"
		 * + "	 values('1','shyam','kmm','Hyd',200,98765)";
		 * 
		 * query = "select * from employee";
		 */

		String insertQuery = "insert into cabcustomer values(?,?,?,?,?,?)";

		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		String custname = sc.next();
		String pLoc = sc.next();
		String dLoc = sc.next();
		int distance = sc.nextInt();
		long ph = sc.nextLong();

		PreparedStatement pstmt = connect.prepareStatement(insertQuery);
		pstmt.setInt(1, id);
		pstmt.setString(2, custname);
		pstmt.setString(3, pLoc);
		pstmt.setString(4, dLoc);
		pstmt.setInt(5, distance);
		pstmt.setLong(6, ph);

		int r = pstmt.executeUpdate();

		System.out.println(r + "rows inserted");

		ResultSet result = stmt.executeQuery("select * from cabcustomer;");

		while (result.next()) {
			System.out.println(result.getInt(1) + " , " + result.getString(2) + " , " + result.getString(3) + " , "
					+ result.getString(4) + " , " + result.getInt(5) + " , " + result.getLong(6));

		}

		result.close();
		pstmt.close();
		stmt.close();
		connect.close();

	}

}
