package jdbc;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;


public class JDBCConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/c02","root","Meghashyam@73");
		Statement stmt = connect.createStatement();
		
		
		
		/*String query = "insert into employee(empId,empname,empSalary,empaddress)"
				+ "                 values(107,'s',234598,'HYD')";
		
		stmt.execute(query);*/
		
	   String query = "select * from customer";
		ResultSet result = stmt.executeQuery(query);
		
		while(result.next()) {
		System.out.println(result.getString(1) + " , " + result.getString(2) + " , " +  result.getString(3)+
		                    " , " + result.getString(4) + " , " +result.getString(5) + " , "+result.getInt(6)
		                    +" , "+result.getInt(7)+ " , "+result.getInt(8)+" , "+result.getInt(9)+" , "
		                    +result.getInt(10)+" , "+result.getString(11)+" , "+result.getString(12));

	}
	result.close();
		
	}
	
}
