package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import collections.cab.cabCustomer;

public class WritingObject {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		cabCustomer c1 = new cabCustomer(101, "Shyam", "lbnagar", "gachibowli", 4, 9889);
		cabCustomer c2 = new cabCustomer(102, "Ramana", "chaitanyapuri", "gachibowli", 5, 9889);

		List<cabCustomer> customerList = new ArrayList<cabCustomer>();
		customerList.add(c1);
		customerList.add(c2);

		// Driver info
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Connection Establishment
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/c02", "root", "Meghashyam@73");

		// Query execution
		Statement stmt = connection.createStatement();
		PreparedStatement pstmt = connection.prepareStatement("insert into cabcustomer values(?,?,?,?,?,?)");

		int i = 0;
		for (cabCustomer c : customerList) {
			int id = c.getCustID();
			String name = c.getCustomerName();
			String pLoc = c.getPickupLocation();
			String dLoc = c.getDropLocation();
			int distance = c.getDistance();
			long ph = c.getPhone();

			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, pLoc);
			pstmt.setString(4, dLoc);
			pstmt.setInt(5, distance);
			pstmt.setLong(6, ph);

			i += pstmt.executeUpdate();

		}
		System.out.println(i + "rows inserted");

		ResultSet result = stmt.executeQuery("select * from cabcustomer;");

		while (result.next()) {
			System.out.println(result.getInt(1) + " , " + result.getString(2) + " , " + result.getString(3) + " , "
					+ result.getString(4) + " , " + result.getInt(5) + " , " + result.getLong(6));
		}

		result = stmt.executeQuery("select count(*) from cabcustomer;");
		
		result.close();
		pstmt.close();
		stmt.close();
		connection.close();
	}
	

}
