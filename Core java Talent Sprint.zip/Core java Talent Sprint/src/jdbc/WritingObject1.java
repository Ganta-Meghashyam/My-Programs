package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import filehandling_point.Point;

public class WritingObject1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// TODO Auto-generated method stub
		Point p1 = new Point("p1", 2, 4);
		Point p2 = new Point("p2", 3, 5);
		Point p3 = new Point("p3", 3, 5);

		List<Point> pointList = new ArrayList<Point>();
		pointList.add(p1);
		pointList.add(p2);
		pointList.add(p3);

		// Driver info
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Connection Establishment
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/c02", "root", "Meghashyam@73");

		// Query execution
		Statement stmt = connection.createStatement();

		String query = "create table point(pName varchar(10),X float,Y float)";

		stmt.execute(query);

		PreparedStatement pstmt = connection.prepareStatement("insert into point values(?,?,?)");

		int i = 0;
		for (Point p : pointList) {
			String name = p.getName();
			float X = p.getX();
			float Y = p.getY();

			pstmt.setString(1, name);
			pstmt.setFloat(2, X);
			pstmt.setFloat(3, Y);

			i += pstmt.executeUpdate();
		}
		System.out.println(i + "rows inserted");

		ResultSet result = stmt.executeQuery("select * from point");

		while (result.next()) {
			System.out.println(result.getString(1) + " , " + result.getFloat(2) + " , " + result.getFloat(3));
		}
		result.close();
		pstmt.close();
		stmt.close();
		connection.close();

	}

}
