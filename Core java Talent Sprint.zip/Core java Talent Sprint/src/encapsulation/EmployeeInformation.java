package encapsulation;

public class EmployeeInformation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		e.setid(10);
		e.setFirstName("megha");
		e.setLastName("shyam");
		e.setSalary(40000);
		
		System.out.println(e);
				

	}

}
