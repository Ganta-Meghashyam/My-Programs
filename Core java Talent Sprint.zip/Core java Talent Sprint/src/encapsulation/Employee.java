package encapsulation;

public class Employee {

	private int id;
	private String firstname;
	private String lastname;
    private int salary;
	

	public void setid(int id) {
		this.id = id;
	}
	public int getid() {
		return id;
	}

	
	public void setFirstName(String firstname) {
		this.firstname = firstname ;
	}
	public String getFirstName() {
		return firstname;
	}

	
	public void setLastName(String lastname ) {
		this.lastname = lastname;
	}

	public String getLastName() {
		return lastname;
	}

	
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getSalary() {
		return salary;
	}
	
	public String getName() {
		return firstname + " " + lastname;
	}
	

	public int getAnnualSalary() {
		return salary*12;
	}
	
	public int raisedSalary(int percent) {
		int newSalary = salary*(100 + percent)+100;
		salary = newSalary;
		return salary;
	}
	
	public String toString() {
		return "Employee:" + "\n"+ "id" +" = " + id +"\n"+ "firstname = " + firstname +"\n"+ "Lastname = " + lastname +"\n"+ "salary = "+ salary + "\n" +getAnnualSalary() +"\n" +raisedSalary(100);
	}
	

	

	
}
