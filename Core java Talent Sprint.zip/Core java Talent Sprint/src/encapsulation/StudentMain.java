package encapsulation;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student stu1 = new Student();
		stu1.setname("Meghashyam");
		stu1.setid(573);
		int[] marks = {98,79,100,94,97};
		stu1.setmarks(marks);
																																			
		System.out.println(stu1);
		
		System.out.println("-------------------------------------------------");
		
		Student stu2 = new Student();
		stu2.setname("Ramandeep");
		stu2.setid(560);
		int[] m = {100,78,97,78,90};
		stu2.setmarks(m);
		
		System.out.println(stu2);
		
		System.out.println("-------------------------------------------------");
		
		Student stu3 = new Student();
		stu3.setname("Sathwik");
		stu3.setid(570);
		int[] m1 = {100,90,98,85,100};
		stu3.setmarks(m1);
		
		System.out.println(stu3);
		System.out.println("------------------------------------------------------");
		
		Student s =Student.getHighestPercentage(stu1, stu2);
		s = Student.getHighestPercentage(s, stu3);
		System.out.println("Highest percentage is :" +s);
		
	}

}
