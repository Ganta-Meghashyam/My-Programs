package encapsulation;

import java.util.Arrays;

public class Student {

	private int id;
	private String name;
	private int marks[];

	// setters

	public void setid(int i) {
		id = i;
	}

	public void setname(String n) {
		name = n;
	}

	public void setmarks(int[] m) {
		marks = m;
	}

	// getters

	public int getid() {
		return id;
	}

	public String getname() {
		return name;
	}

	public int[] getmarks() {
		return marks;
	}

	public float getpercentage() {
		int sum = 0;

		for (int i = 0; i < marks.length; i++) {
			sum += marks[i];
		}
		return ((float) (sum * 100) / 500);
	}
	
	public static Student getHighestPercentage(Student s1 , Student s2) {
		if(s1.getpercentage() > s2.getpercentage())
			return s1;
		else
			return s2;
	}

	
	
	@Override
	public String toString() {
		return "Student :\n id=" + id + "\n name=" + name + "\n marks=" + Arrays.toString(marks) + "\n getmarks()="
				+ Arrays.toString(getmarks()) + "\n getpercentage()=" + getpercentage();
	}

}
