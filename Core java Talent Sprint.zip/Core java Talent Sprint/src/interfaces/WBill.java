package interfaces;

public class WBill implements Bill  {
	
	double x;
	
	 public WBill(double x) {
		// TODO Auto-generated constructor stub
		 this.x = x;
	}


	@Override
	public double calcBill(double no_of_units) {
		// TODO Auto-generated method stub
		return no_of_units;
	}

	@Override
	public void displayBill() {
		// TODO Auto-generated method stub
		System.out.println(calcBill(x));
	}

}
