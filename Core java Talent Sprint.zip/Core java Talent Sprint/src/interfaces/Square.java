package interfaces;

public class Square implements Shape {
	
	double side;
	
	public Square(double side) {
		this.side = side;
	}

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return side*side;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 4*side;
	}

	@Override
	public String toString() {
		return "Square [side=" + side + ", Area()=" + getArea() + ", Perimeter()=" + getPerimeter() + "]";
	}
	
	
	
	

}
