package interfaces.ROIcalculator;

public class SBI implements Bank{
	
	private Customer customer;
	
	public SBI() {}
	
	public SBI(Customer customer) {
		super();
		this.customer = customer;
	}

	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	
	public double calcROI() {
		
		 return customer.getInvestment() / customer.getTenure();
	}

}
