package interfaces.ROIcalculator;

public class Customer {
	
	private float investment;
	private float tenure;
	
	public Customer() {
		
	}
	
	public Customer(float investment, float tenure) {
		super();
		this.investment = investment;
		this.tenure = tenure;
	}
	
	
	public float getInvestment() {
		return investment;
	}
	public void setInvestment(float investment) {
		this.investment = investment;
	}
	
	
	public float getTenure() {
		return tenure;
	}
	public void setTenure(float tenure) {
		this.tenure = tenure;
	}
	
	
	

}
