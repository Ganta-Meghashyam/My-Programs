package interfaces.ROIcalculator;

public interface Bank {
	
	public double calcROI();

}
