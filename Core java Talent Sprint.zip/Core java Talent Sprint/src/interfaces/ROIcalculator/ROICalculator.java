package interfaces.ROIcalculator;

public class ROICalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1 = new Customer(50000 , 5);
		
		SBI sbi = new SBI(c1);
		
		System.out.println(sbi.calcROI());
		
		ICCI icci = new ICCI(c1);
		System.out.println(icci.calcROI());
		

	}

}
