package interfaces.ROIcalculator;

public class ICCI implements Bank {

	private Customer customer;

	public ICCI() {
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public ICCI(Customer customer) {
		super();
		this.customer = customer;
	}

	
	public double calcROI() {
		
		return customer.getInvestment() / customer.getTenure();
	}

}
