package interfaces;

public class CalculateBillAmount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EBill e = new EBill(5);
        e.displayBill();
        
        System.out.println("----------------------------------------");
        
        WBill w = new WBill(10);
        w.displayBill();
	}

}
