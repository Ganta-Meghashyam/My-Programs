package interfaces;

public class EBill implements Bill{

	double x;
	
	public EBill(double x) {
		this.x = x;
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	@Override
	public double calcBill(double no_of_units) {
		
		return no_of_units;
	}

	@Override
	public void displayBill() {
		// TODO Auto-generated method stub
		System.out.println(calcBill(x));
		
	}
	

}
