package interfaces;

public interface Shape {
	
	public double getArea();	
	public double getPerimeter();
	
	public static double getMaxArea(double area1 , double area2) {
		if(area1 > area2) {
			return area1;
		}
		return area2;
	}
			
		
	
	

}
