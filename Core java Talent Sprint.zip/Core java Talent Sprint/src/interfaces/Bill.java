package interfaces;

public interface Bill {
	

	public double calcBill(double no_of_units);
	public void displayBill();
	

}
