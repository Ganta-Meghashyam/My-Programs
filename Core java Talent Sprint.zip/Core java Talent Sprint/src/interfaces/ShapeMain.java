package interfaces;

public class ShapeMain {
	
	public static void main(String args[]) {

	Circle c1 = new Circle(4);
	System.out.println(c1);
	Circle c2 = new Circle(5);
	System.out.println(c2);
	
	System.out.println("-------------------------------------------");
	System.out.println(Shape.getMaxArea(c1.getArea(), c2.getArea()) + " is having maximum area");
	
	
	System.out.println("--------------------------------------------------");
	
	Rectangle r = new Rectangle(3,4);
	System.out.println(r);
	
	System.out.println("----------------------------------------------");
	
	Square s = new Square(3);
	System.out.println(s);
	
}
}