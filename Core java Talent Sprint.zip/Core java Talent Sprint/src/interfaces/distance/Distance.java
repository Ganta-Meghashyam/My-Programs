package interfaces.distance;

public interface Distance {

	public double getDistanceBetweenTwoPoints( Point p1 , Point p2);
	public void getDistanceBetweenTwoPoints(Point[] p); 
}
