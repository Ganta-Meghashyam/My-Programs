package interfaces.distance;

public class DistanceCalculator implements Distance{
	
	 
	public double getDistanceBetweenTwoPoints(Point p1, Point p2) {
		
		float x1 = p1.getX();
		float y1 = p1.getY();
		
		float x2 = p2.getX();
		float y2 = p2.getY();
		
		return Math.sqrt( ((x2-x1)*(x2-x1)) + ((y2-y1)*(y2-y1)) );
	}

	@Override
	public void getDistanceBetweenTwoPoints(Point[] p) {
		
		for(int i = 0 ; i < p.length ; i++) {
			float x1 = p[i].getX();
			float y1 = p[i].getY();		
		
		for(int j = i+1 ; j < p.length ; j++) {
			float x2 = p[j].getX();
			float y2 = p[j].getY();	
			
			System.out.println("Distance between"+(p[i] + "&"+ p[j] + " is "+Math.sqrt( ((x2-x1)*(x2-x1)) + ((y2-y1)*(y2-y1)) )));
		}
		}
		
			
		
	}

}
