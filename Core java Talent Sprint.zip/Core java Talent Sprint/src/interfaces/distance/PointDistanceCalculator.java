package interfaces.distance;

import java.util.ArrayList;
import java.util.HashSet;

public class PointDistanceCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Point p1 = new Point(1.2f , 3.2f);
		Point p2 = new Point(1.6f , 3.7f);
		Point p3 = new Point(1.8f , 4.2f);
		Point p4 = new Point(4.2f , 3.5f);
		
		Point[] p = {p1,p2,p3,p4}; 
		
		
		DistanceCalculator d = new DistanceCalculator();
		
		d.getDistanceBetweenTwoPoints(p);
		System.out.println("-------------------------------------------------");

		//collections model
		ArrayList<Point> pointList = new ArrayList<Point>();
		pointList.add(p1);
		pointList.add(p2);
		pointList.add(p3);
		pointList.add(p4);
		
		System.out.println(pointList);
		
		for(int i = 0; i < pointList.size() ; i++) {
			System.out.println(i +":" + pointList.get(i));
			
			//unordered pair
			HashSet<Point> pointSet = new HashSet<Point>();
			pointSet.add(p1);
			pointSet.add(p2);
			pointSet.add(p3);
			pointSet.add(p4);
			
			System.out.println(pointSet);
			//we cannot use for loop for hash set 
			for(Point ps : pointSet) {
				System.out.println(ps);
			}
			
		}
	}

}
