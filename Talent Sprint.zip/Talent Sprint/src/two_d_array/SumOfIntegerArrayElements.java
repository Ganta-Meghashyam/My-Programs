package two_d_array;

import java.util.Scanner;

public class SumOfIntegerArrayElements {

	public static int sumOfElements(int arr[][]) {
		int sum = 0;
		for (int[] numArray : arr) {
			for (int num : numArray)
				sum += num;
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your inputs:");
		int arr[][] = new int[3][3];

		// for arr[] inputs;

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = sc.nextInt();
			}
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println("");
		}
		System.out.println("The sum of elements of arr[][] is:" + sumOfElements(arr));

	}
}
