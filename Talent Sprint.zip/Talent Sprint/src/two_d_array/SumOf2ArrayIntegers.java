
package two_d_array;

import java.util.Scanner;

public class SumOf2ArrayIntegers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rows = 3, columns = 3;
		int sum[][] = new int[rows][columns];
		int arr1[][] = new int[rows][columns];
		int arr2[][] = new int[rows][columns];

		// for arr1[][] inputs;
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				arr1[i][j] = sc.nextInt();
			}
		}
        
		//Displaying arr1[] output
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				System.out.print(arr1[i][j] + " ");
			}
			System.out.println("");
		}

		// for arr2[][] inputs
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				arr2[i][j] = sc.nextInt();
			}
		}
        
		//Displaying arr2[][] output
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				System.out.print(arr2[i][j] + " ");
			}
			System.out.println("");
		}
		
        //Adding sum of arr1[][] and arr2[][]
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				sum[i][j] = arr1[i][j] + arr2[i][j];
			}
		}
		System.out.println(" ");
		
		//Displaying output
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				System.out.print(sum[i][j] + " ");

			}
			System.out.println(" ");

		}
	}
}
