package two_d_array;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[][] = { { 1, 2 }, { 1, 2, 6, 5 }, { 11, 65, 34, 23, }, { 2 }, { 2, 7, 6 } };
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]+ " ");
			}
			System.out.println(" ");
		}
		 
		System.out.println("--------------------------------------");
       
		 //for each loop;
		for(int[] numArray :arr) {
			for(int num : numArray) {
				System.out.print(num + " ");
			}
			System.out.println("");
		}
		
	}

}
