package two_d_array;

public class HighestNumberInRow {

	public static int[] findMatrixInEachRow(int[][] matrix) {
		int max;

		int[] maxrows = new int[matrix.length];

		for (int i = 0; i < matrix.length; i++) {
			max = matrix[i][0];

			for (int j = 0; j < matrix[i].length; j++) {
				if (max < matrix[i][j])
					max = matrix[i][j];
			}

			maxrows[i] = max;
		}
		return maxrows;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[][] = new int[][] { { 10, 8, 9 }, { 4, 5, 6 }, { 1, 2, 3 } };
		int[] maxrows = findMatrixInEachRow(arr);

		for (int num : maxrows)
			System.out.println(num);

	}

}
