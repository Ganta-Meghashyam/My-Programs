package two_d_array;

public class ArrayRotation {

	public static int[] rotateByOne(int arr[]) {
		int i, temp;
		temp = arr[arr.length - 1];
		for (i = arr.length - 1; i > 0; i--)
			arr[i] = arr[i - 1];
		arr[i] = temp;

		return arr;

	}

	/* 
	 * temp =arr[arr.length-1] //(arr.length=4) 
	 
	 * arr[arr.length-1] = arr[arr[length-2]; //{1,2,4,3}; 
	 * arr[arr.length-2] =arr[arr[length-3];  //{1,4,2,3}; 
	 * arr[arr.length-3] = arr[arr[length-4]; //{4,1,2,3};
	  
	 * arr[0] = temp; //{4,1,2,3};
 
	 */

	public static int[] rotateByN(int arr[], int n) {
		for (int i = 0; i < n; i++) { // 2 times repetation //{4,1,3,2},{4,3,1,2},{3,4,1,2};
			arr = rotateByOne(arr);
		}
		return arr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 2, 3, 4 };

		int rotatedArray[] = rotateByN(arr, 2);

		for (int num : rotatedArray)
			System.out.print(num + " ");

	}
}
