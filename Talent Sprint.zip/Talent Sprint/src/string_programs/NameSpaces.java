package string_programs;

import java.util.Scanner;

public class NameSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();

		String[] nameparts = name.split(" ");

		for (String parts : nameparts)
			System.out.println(parts);

	}

}