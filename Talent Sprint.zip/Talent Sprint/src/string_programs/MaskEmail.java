package string_programs;

public class MaskEmail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str = new StringBuffer("gantameghashyam@gmail.com");
		str.replace(2, 15, "xxxxxxxxxxxxxx");
		System.out.println(str);

	}

}
