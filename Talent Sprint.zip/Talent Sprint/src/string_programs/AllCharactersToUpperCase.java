package string_programs;

import java.util.Scanner;

public class AllCharactersToUpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your word:");
		String str = sc.nextLine();
		
		System.out.println(str.toUpperCase());

	}

}
