package string_programs;

import java.util.Scanner;

public class CharRepeatation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter your word");
		String str = sc.nextLine();

		System.out.println("enter your character");
		char ch = sc.next().charAt(0);

		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == ch)
				System.out.println(i);
		}

	}
}
