package string_programs;

public class PalindromeChar {

	public static void main(String args[]) {

		String str = new String("madams");

		StringBuffer str1 = new StringBuffer(str);

		String str2 = new String(str1.reverse());
//		System.out.println(str2);

		if (str.equals(str2)){
			System.out.println(str + " is a palindrome");
		} else {
			System.out.println(str + " is not a palindrome");
		}

	}

}
