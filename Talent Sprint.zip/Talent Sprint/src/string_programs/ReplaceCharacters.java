package string_programs;

public class ReplaceCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Doday is dhe besd day of the resd of my life.";
		String str1 = str.replace('D', 'T');

	}

}
