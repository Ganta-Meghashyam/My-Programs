package string_programs;

import java.util.Scanner;

public class String2VariablesContainSame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first word:");
		String str = sc.nextLine();
		System.out.println("Enter second word:");
		String str1 = sc.nextLine();

		if (str.equals(str1)) {
			System.out.println("it contains same words");
		} else
			System.out.println("it contains different words ");

	}

}
