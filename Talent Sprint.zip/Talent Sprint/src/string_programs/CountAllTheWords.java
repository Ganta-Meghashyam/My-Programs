package string_programs;

import java.util.Scanner;

public class CountAllTheWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your word:");
		String str = sc.nextLine();
		
		String[] parts = str.split(" "); //megha shyam yadav
		System.out.println(parts.length);
	}

}
