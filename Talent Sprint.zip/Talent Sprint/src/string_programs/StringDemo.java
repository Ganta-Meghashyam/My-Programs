package string_programs;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = new String("meghashyam");
		String str1 = new String(str);

		System.out.println(str.charAt(2));
		System.out.println(str.indexOf("m"));
		System.out.println(str.substring(2));
		System.out.println(str.lastIndexOf("m"));
		System.out.println(str.substring(1, 8));
		System.out.println(str.compareToIgnoreCase(str1));
		System.out.println(str.compareTo(str1));
		System.out.println(str.concat(".com"));
		System.out.println(str.replace("shyam" , "megha"));
		System.out.println(str.equals(str1));
		
		

	}

}
