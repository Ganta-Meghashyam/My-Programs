package Method;

import java.util.Scanner;

public class Factorial {
	
	public static long calFactorial(long num)
	{
		int factorial = 1;
		for(long i =1; i<=num;i++)
		{
			factorial *= i; 
		}
		return factorial;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       System.out.println("enter your number");
       int num =sc.nextInt();
       System.out.println(calFactorial(num));
	}

}
