package Method;

public class DavidWork {
    
	public static int calDavidWorkOut(int n)
	{
		int a = 1,b=2,c=3;
		int res=0;
		for(int i=4;i<=n;i++) {
			res =a+b+c;
		    a=b;
		    b=c;
		    c=res;
		
	}
	return res;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(calDavidWorkOut(9));

	}

}
