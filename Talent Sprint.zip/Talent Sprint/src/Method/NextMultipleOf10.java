package Method;

import java.util.Scanner;

public class NextMultipleOf10 {

	public static int nextMultiple(int n) {
		if (n % 10 != 0) {
			n = n + (10 - (n % 10)); //or n=((n/10)+1)*10;
		}
		return n;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 2 numbers");

		int n1 = sc.nextInt();
		int n2 = sc.nextInt();

		System.out.println(nextMultiple(n1));
		System.out.println(nextMultiple(n2));

	}

}
