package Method;

import java.util.Scanner;

public class GradingSystem {
    
	
	public static String calGrade(int num)
	{
		String grade = " ";
		if(num<25)
			grade = "F";
		else if(num<45)
			grade = "E";
		else if(num<50)
			grade = "D";
		else if(num<60)
			
			grade = "C";
		else if(num<80)
			grade = "B";
		else if(num<100)
			grade = "A";
		return grade;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
         Scanner sc = new Scanner(System.in);
 		System.out.println("Enter 2 numbers:");
 		System.out.println("This program takes input number of marks obtained by a student \r\n");
 		
 		
 		System.out.print("Enter the marks obtained - ");  
 		int marks= sc.nextInt();
 		
 		String grade =calGrade(marks);
 		System.out.print("Grade of the student is - " + grade); 
 		sc.close();
	}

}
