package Method;
import java.util.Scanner;
public class OddPalindrome {
	
	public static int reverse(int num) 
	{
		int reverse = 0, digit;
		while (num > 0) {
			digit = num % 10;
			reverse = reverse*10+digit;
			num = num / 10;
	}
		return reverse;
	}
	
	public static boolean isPalindrome(int num) 
	{
		return num == reverse(num);
		}
	
	
	public static boolean isAllDigitsOdd(int num) 
	{
		while(num>0)
		{
			int digit = num % 10;
			num = num / 10;
			if (digit % 2 == 0)
				return false;
			}return true;
			}
	
	
	public static boolean isOddPalindrome(int num) 
	{
		return isAllDigitsOdd(num) && isPalindrome(num);
		}
	
	
	public static void main(String[] args) 
	{
		System.out.println("Palindrome check and odd digits check of the input number\r\n");
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the number- ");
		
		int number = sc.nextInt();
		
		if (isOddPalindrome(number))
			System.out.println("The given number " + number + " is a palindrome with only odd digits");
		
		else
			System.out.println("The given number " + number + " isn't a palindrome at all");
		sc.close();
		}
}