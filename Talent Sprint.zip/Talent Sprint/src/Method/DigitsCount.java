package Method;

import java.util.Scanner;

public class DigitsCount {

	public static int digitCount(int num) {
		
		int count = 0;
		
		
		while (num > 0) {
			count++;
			num = num / 10;
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers:");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();

		System.out.println(digitCount(num1));
		System.out.println(digitCount(num2));
		sc.close();
	}

}
