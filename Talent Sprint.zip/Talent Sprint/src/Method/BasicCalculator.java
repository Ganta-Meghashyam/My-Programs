package Method;

import java.util.Scanner;

public class BasicCalculator {
	  
	
      public static int add(int num1,int num2)
      {
          int sum = num1 + num2;
          return sum;
      }
      
      public static int sub(int num1,int num2)
      {
          int subtract = num1 - num2;
          return subtract;
      }
      
      
      public static int mul(int num1,int num2)
      {
          int multiply = num1 * num2 ;
          return multiply ;
      }   
      
      
      public static int div(int num1,int num2)
      {
          int divide = num1 / num2 ;
          return divide ;
      }   
      
      
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter your number:");
		int x = sc.nextInt();
		
		System.out.print("Enter your number:");
		int y = sc.nextInt();

		int sum = add(x,y);
		int subtract = sub(x,y);
		int multiply = mul(x,y);
		int divide = div(x,y);
		
		System.out.println("Sum:" +sum);
		System.out.println("Difference:" +subtract);
		System.out.println("Product:" +multiply);
		System.out.println("Division:" +divide);
	}

}
