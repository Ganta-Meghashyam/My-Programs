package Method;

import java.util.Scanner;

public class OddDigitCheck {
	
	public static boolean isAllDigitsOdd(int num) {
		while(num>0) {
			int digit = num % 10;
			num = num/10;
			if(digit % 2 == 0) 
				return false;
			}
		
			return true;
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		
		int num = sc.nextInt();
		
		System.out.println(isAllDigitsOdd(num));

	}

}
