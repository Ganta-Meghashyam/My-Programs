package Method;


public class FizzBuzzSequence {
	
	public static String fizzBuzz(int num)
	{
		String res = "";
		
		
		if(num % 3 == 0)
			res += "FIZZ";
		
		if(num % 5 ==0)
			res += "BUZZ";
		
		if(num % 7 == 0)
			res += "DIZZ";
		
		if(res.length() == 0)
			res = res+num;
		
		return res;
	}
	
	public static String genFizzBuzz(int start , int end)
	{
		String res = "";
		
		for(int num = start; num<=end; num++) {
			res += fizzBuzz(num) + "\n";
		}
		return res;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(genFizzBuzz(1, 100));
	}

}
