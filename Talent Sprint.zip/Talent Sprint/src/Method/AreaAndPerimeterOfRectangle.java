package Method;

import java.util.Scanner;

public class AreaAndPerimeterOfRectangle {
    
	 public static int calArea(int length,int breadth) {
		 
         int area = length * breadth;
         return area;
     }
	 
	 public static int calPerimeter(int length,int breadth) {
		 
         int perimeter = 2*(length + breadth);
         return perimeter;
     }
	 
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter your number:");
		int x = sc.nextInt();
		
		System.out.print("Enter your number:");
		int y = sc.nextInt();

		int area = calArea(x,y);
		int perimeter = calPerimeter(x,y);
		
		System.out.println("area of rectangle is:"+area);
		System.out.println("perimeter of rectangle is:"+perimeter);

	}

}
