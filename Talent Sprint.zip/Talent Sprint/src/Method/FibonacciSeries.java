package Method;

public class FibonacciSeries {
	public static String calFibonacciSeries(int num) {
		String fibonacciseries = "0 1";
		int n1 = 0, n2 = 1, n;
		for (int i = 2; i <= num; i++) {
			n = n1 + n2;
			fibonacciseries += " "+ n + "";
			n1 = n2;
			n2 = n;
		}
		return fibonacciseries;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(calFibonacciSeries(10));

	}

}
