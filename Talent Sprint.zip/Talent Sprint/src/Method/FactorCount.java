package Method;

import java.util.Scanner;

public class FactorCount {
	
	public static int calCountFactors(int num)
	{
		int sum = 0;
		int count = 0;
		for(int i = 1; i<=num ; i++)
		{
		if(num % i == 0) {
			sum = sum+i;
		    count++;
	}
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your number");
        int num = sc.nextInt();
        System.out.println("the count factor of " + num + " is: " +calCountFactors(num));
	}

}
