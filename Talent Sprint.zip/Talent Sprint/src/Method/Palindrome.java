package Method;

import java.util.Scanner;

public class Palindrome {

	public static int reverseOfNumber(int num) {
		int reverse = 0;
		int digit ;
		while(num > 0)
		{
			digit = num % 10;
			reverse = reverse * 10 + digit;
			num = num / 10;
			
		}
		
		return reverse;
	
	}
	
	public static boolean isPalindrome(int num) {
		return reverseOfNumber(num) == num;
	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num;
		System.out.println("Give a Number:");
		num = sc.nextInt();
		if (isPalindrome(num)) {
			System.out.print("Given number is palindrome");
		} else {
			System.out.print("Given number is not palindrome");
		}
	}
}
