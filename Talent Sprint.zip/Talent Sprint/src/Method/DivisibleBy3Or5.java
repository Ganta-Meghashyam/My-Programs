
package Method;

import java.util.Scanner;

public class DivisibleBy3Or5 {

	public static int range(int num1, int num2) {
		int sum = 0;
		
		for (int i = num1; i <= num2; i++) {
			if ((i % 3 == 0) || (i % 5 == 0)) {
				sum = sum + i;
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int start = sc.nextInt();
		int end = sc.nextInt();

		
		System.out.println("The sum of divisible numbers of 3 or 5 is:" +range(start,end));

	}

}
