package Method;

public class PrimeNumberRange {

	public static boolean isPrime(int num) {
		if (num == 1)
			return false;

		if (num == 2)
			return true;

		for (int i = 2; i <= num / 2; i++) {
			if (num % i == 0)
				return false;
		}
		return true;
	}

	public static String genPrimeNum(int start, int end) {
		String result = " ";

		for (int num = start; num <= end; num++) {
			if (isPrime(num))
				result += num + " " ;
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(genPrimeNum(1, 100));

	}

}
