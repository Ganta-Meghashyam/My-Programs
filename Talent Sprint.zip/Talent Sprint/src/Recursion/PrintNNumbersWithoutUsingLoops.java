package Recursion;

public class PrintNNumbersWithoutUsingLoops {

	public static int printNos(int n) {
		if (n > 0) {
			System.out.print(n + " ");
			printNos(n - 1);
		}
		return n;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		printNos(100);

	}

}
