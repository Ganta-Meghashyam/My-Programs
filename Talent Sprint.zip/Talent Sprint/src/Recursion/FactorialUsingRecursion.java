package Recursion;

public class FactorialUsingRecursion {

	public static int PrintFactorial(int n) {

		int factorial = 1;

		if (n >= 1) {
			factorial = n * PrintFactorial(n - 1);
		}
		return factorial;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(PrintFactorial(4));

	}

}
