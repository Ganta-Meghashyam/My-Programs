package conditional_programs;

import java.util.Scanner;

public class SumOfEvenNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number");
		int num = sc.nextInt();
		
		int sum=0;
		
		for(int i=1 ; i<=num ; i++)
		{
			if(i%2==0)
			{
				sum=sum+i;
				
			}
			
		}
		System.out.println(sum);
	}

}
