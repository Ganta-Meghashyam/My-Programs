package conditional_programs;

import java.util.Scanner;

public class CheckFiveDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Number");
		int num = sc.nextInt();
		
		if(num >= 10000 && num <= 99999)
		{
			System.out.println(num + " is a five digit number ");
		}
		else
		{
			System.out.println(num + " is not a five digit number ");
		}

	}

}
