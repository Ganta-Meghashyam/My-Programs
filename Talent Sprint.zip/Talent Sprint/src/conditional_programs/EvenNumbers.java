package conditional_programs;

import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	       System.out.println("Enter your number");
	       int num = sc.nextInt();
	       
	       
	       for(int i=2;i<=num;i++)
	       {
	    	      if(i%2==0);{
	    	    	
	    	   System.out.println(i+ "  ");
	    	      }

	}
	}
	

}
