package conditional_programs;

import java.util.Scanner;

public class CubesOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("enter your number");
        int num = sc.nextInt();
        
        int digit,sum=0;
        
        while(num>0)
        {
        	digit = num%10;
        	sum=sum+digit;
        	num=num/10;
        	digit=digit*digit*digit;
        	System.out.println(digit);
        }
	}

}
