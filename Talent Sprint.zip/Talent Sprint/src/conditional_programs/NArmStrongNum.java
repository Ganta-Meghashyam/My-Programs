package conditional_programs;

import java.util.Scanner;

public class NArmStrongNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your number");
        int num = sc.nextInt();
        
        int n = num;
        int number = num;
        int count = 0;
        
        //to count number of digits
        
        while(num>0)
        {
        	count++;
        	num = num/10;
        }
        
        //sum of (count) digit
        int sum = 0;
        
        while(n>0)
        {
        	int digit = n % 10;
        	sum = sum + (int)Math.pow(digit,count);
        	n = n / 10;
        }
        if(number == sum)
        {
        	System.out.println(number + " is an armstrong number ");
        }
        else
        {
        	System.out.println(number + " is not an armstrong number ");
        }
        	
	}

}
