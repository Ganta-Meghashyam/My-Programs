package conditional_programs;

import java.util.Scanner;

public class DigitsofNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number");
		int num = sc.nextInt();
		
		int sum=0 ;int digit;
		
		while(num>0)
		{
			digit = num %10;
			sum=sum+digit;
			num = num/10;
			System.out.println(digit);
		}
         
	}

}
