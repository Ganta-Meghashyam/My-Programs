package conditional_programs;

import java.util.Scanner;

public class SumOfNNatuaralNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your number:");
        int n = sc.nextInt();	
        
        int i, sum = 0;
        
        for (i=1 ; i<=n ; i++)
        {
        	sum = sum+i;
        }
	System.out.println(sum);
	}

}
