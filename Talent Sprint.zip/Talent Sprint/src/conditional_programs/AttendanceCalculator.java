package conditional_programs;

import java.util.Scanner;

public class AttendanceCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       
       System.out.println("Enter total classes scheduled");
       int totalClasses = sc.nextInt();
       
       System.out.println("Enter the classes attended ");
       int classesAttended = sc.nextInt();
       
       double attendancePercentage = ((double)classesAttended/totalClasses)*100;
       System.out.println(attendancePercentage);
       
      
       if(attendancePercentage>75)
       {
    	   System.out.println("student can attend exam");
       }
       else
       {
    	   System.out.println("student cannot attend exam");
       }
       
       
	}

}
