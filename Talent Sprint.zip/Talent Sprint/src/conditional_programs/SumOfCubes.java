package conditional_programs;

import java.util.Scanner;

public class SumOfCubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        System.out.println("enter your number");
        int num = sc.nextInt();
      
        int temp = num ;
       
        int digit,sum=0;
        
        while(num>0)
        {
        	digit = num%10;
        	num = num/10;
        	digit=digit*digit*digit;//Math.pow(0,3);
        	sum= sum+digit;
        	
        	
        }
        System.out.println("Sum of cubes of " +temp + " is " +sum);
	}

}
