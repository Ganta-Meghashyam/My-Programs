package array_programs;

public class SumOfNumbers {
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 10, 20, 34, 54, 65 };
		int sum = 0;

		for (int i=0; i<arr.length;i++) {
			sum += arr[i];
		}
		System.out.println(sum);

	}

}
