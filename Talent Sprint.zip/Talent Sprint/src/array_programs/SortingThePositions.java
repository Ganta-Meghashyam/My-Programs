package array_programs;

public class SortingThePositions {
	
	public static boolean sortingThePositions(int arr[]) {
		for(int i = 0 ; i<2 ; i++)
		
		{
		     arr[4] = arr[1];
		     arr[1] = arr[2];
		     
		     
		}
		return true;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
