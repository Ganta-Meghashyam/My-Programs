package array_programs;

public class GreatestNumber {

	public static int greatestNumber(int arr[]) {
		int maximum = arr[0];
		for (int i = 1; i < arr.length; i++) {

			if (arr[i] > maximum) {
				maximum = arr[i];
			}
		}
		return maximum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 12, 54, 34, 76, 45 };

		System.out.println(greatestNumber(arr));

	}
}
