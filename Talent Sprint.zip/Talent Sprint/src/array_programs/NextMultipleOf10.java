package array_programs;

public class NextMultipleOf10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 11, 45, 67, 34, 87 };

		for (int num : arr) {
			if (num % 10 != 0) {
				System.out.println(((num / 10) + 1) * 10);
			} else {
				System.out.println(num);
			}
		}

	}

}
