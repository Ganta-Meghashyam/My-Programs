package array_programs;

import java.util.Scanner;

public class SumOfCubes {
	
	public static int sumOfElements(int arr[]) {
		int sum = 0;
		for (int num : arr) {
			sum += num;
		}
		return sum;
	}
	
	public static int calCubes(int arr[])
	{
		int sum = sumOfElements(arr);
		return   (int) Math.pow(sum,3); 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int arr[] = new int[5];
		for(int i = 0; i<arr.length ; i++)
		{
			arr[i] = sc.nextInt();
		}
        System.out.print("sum of cubes of elements is: ");
		System.out.println(calCubes(arr));

	}

}
