package array_programs;

public class AverageValue {

	public static int sumOfElements(int arr[]) {
		int sum = 0;
		for (int num : arr) {
			sum += num;
		}
		return sum;
	}
	public static double calAverage(int arr[])
	{
		int sum = sumOfElements(arr);
		return (double) sum/arr.length; 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  arr[] = { 13, 74, 35, 76, 45 };
        System.out.print("Average of sum of elements is: ");
		System.out.println(calAverage(arr));
		
			
		

	}

}
