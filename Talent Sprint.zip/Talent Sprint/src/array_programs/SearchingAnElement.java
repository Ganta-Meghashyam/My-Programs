package array_programs;

import java.util.Scanner;

public class SearchingAnElement {

	public static boolean isFound(int arr[], int search) {
		for (int i = 0; i < arr.length; i++) {
			if (search == arr[i])
				return true;
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 12, 78, 45, 66, 98, 34, 67, 23, 16, 39 };
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int search = sc.nextInt();

		boolean result = isFound(arr, search);

		if (result)
			System.out.println("Element found");
		else
			System.out.println("element not found");

	}
}
