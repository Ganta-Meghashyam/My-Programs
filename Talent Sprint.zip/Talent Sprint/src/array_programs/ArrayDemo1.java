package array_programs;

import java.util.Scanner;

public class ArrayDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[5];
		for(int i = 0; i<arr.length ; i++)
		{
			arr[i] = sc.nextInt();
		}
		
		for(int num : arr) {
			System.out.println(num);
		}

	}

}
