package NestedLoops;

public class NumberPattern6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*1
		 *12
		 *123
		 *1234
		 *12345
		 *123456
		 *1234567
		 *123456
		 *12345
		 *1234
		 *123
		 *12
		 *1
		 */
		
		//for upper numbers
		int n = 7;
		
		for(int i = 1 ; i <= n ; i++) {
			for(int j = 1 ; j <= i ; j++ ) {
				System.out.print(j);
			}
			System.out.println("");
		}
		
		//for reverse numbers
		
		for( int i = n-1 ; i >= 1  ; i--) {
			for(int j = 1 ; j <= i ; j++ ) {
				System.out.print(j);
			}
			System.out.println("");
		}
		

	}

}
