package NestedLoops;

public class NumberPattern15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 1 2 3 4 5 6 7 
		 * 2 3 4 5 6 7 1
		 * 3 4 5 6 7 1 2 
		 * 4 5 6 7 1 2 3
		 * 5 6 7 1 2 3 4 
		 * 6 7 1 2 3 4 5
		 * 7 1 2 3 4 5 6
		 * 
		 */
		
		int n = 7;
		for(int i = 1 ; i <= n ; i++) {
			for(int j = i ; j <= n ; j++) {
				System.out.print(j + " ");
			}
			for(int k = 1  ; k < i ; k++) {
				System.out.print(k + " ");
			}
			System.out.println();
		}

	}

}
