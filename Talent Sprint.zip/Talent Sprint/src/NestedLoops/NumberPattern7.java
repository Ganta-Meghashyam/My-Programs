package NestedLoops;

public class NumberPattern7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 7 6 5 4 3 2 1
		 * 7 6 5 4 3 2
		 * 7 6 5 4 3
		 * 7 6 5 4
		 * 7 6 5
		 * 7 6
		 * 7
		 */
		
		int n = 7;
		for(int i = 1 ; i <= n;  i++) {
			for(int j = n ; j >= i  ; j--) {
				System.out.print(j+ " ");
			}
			System.out.println();
			
		}
		
	}

}
