package NestedLoops;

public class NumberPattern12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 1 2 3 4 5 6 7
		 *   2 3 4 5 6 7
		 *     3 4 5 6 7 
		 *       4 5 6 7
		 *         5 6 7
		 *           6 7
		 *             7
		 *           6 7
		 *         5 6 7
		 *       4 5 6 7
		 *     3 4 5 6 7
		 *   2 3 4 5 6 7
		 * 1 2 3 4 5 6 7 
		 */
		
		int n = 7;
		
		//for upper half
		for(int i = 1 ; i <= n ; i++) {
			
			for(int j = 1 ; j < i ; j++) {
			
				System.out.print(" ");
			}
			
			for(int k = i ; k <= n ; k++) {
				
				System.out.print(k);
				
		}
			System.out.println();
			
	}
		
		//for lower half
		for(int i = n ; i >= 1 ; i-- ) {
			for(int j = 1 ; j < i ; j++) {
				System.out.print(" ");
			}
			for(int k = n ; k >= i ; k--) {
				System.out.print(k);
			}
			System.out.println();

		}
		
   }
}
