package demo;

public class DifferenceOf2Digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=73;
		int n1=n/10;
		int n2=n%10;
		System.out.println(n2-n1);

	}

}
