package demo;

import java.util.Scanner;

public class AddingSecondsToTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Hours:");
		int hour = sc.nextInt();

		System.out.println("Minutes:");
		int minutes = sc.nextInt();

		System.out.println("seconds:");
		int seconds = sc.nextInt();

		int hour_to_sec = 60 * 60;
		int min_to_sec = 60;

		int totalseconds = (hour * hour_to_sec) + (minutes * min_to_sec) + seconds;
		int add_sum_to_totalseconds = 100 + totalseconds;

		int sec_to_hr = add_sum_to_totalseconds / hour_to_sec;
		int sec_to_min = (add_sum_to_totalseconds / min_to_sec) - (sec_to_hr * 60);
		int sec = add_sum_to_totalseconds - (sec_to_hr * hour_to_sec) - (sec_to_min * min_to_sec);

		System.out.println(sec_to_hr + "hours" + " " + sec_to_min + "minutes" + " " + sec + "seconds");

	}

}
