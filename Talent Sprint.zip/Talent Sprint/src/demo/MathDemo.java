package demo;

public class MathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         System.out.println(Math.pow(3,2));
         System.out.println(Math.round(3.5));
         System.out.println(Math.ceil(3.1));
         System.out.println(Math.floor(3.9));
         System.out.println(Math.log10(100));
         System.out.println(Math.getExponent(504/(28*2)));
	}

}
