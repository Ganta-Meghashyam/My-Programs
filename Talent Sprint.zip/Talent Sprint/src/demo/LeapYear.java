package demo;

public class LeapYear {

	public static boolean checkLeapYear(int year) {
		if (year % 400 == 0) {

			return true;
		}
		if (year % 4 == 0) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 2003;
		if (checkLeapYear(num) == true) {
			System.out.println(num + " is a leap year");
		} else {
			System.out.println(num + " is not a leap year");

		}

	}

}
