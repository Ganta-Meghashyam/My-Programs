package demo;

import java.util.Scanner;

public class CountDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers:");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int count=0;
		
		while (num1 != 0) {
			num1 = num1 / 10;
			count++;
		}
		System.out.println(count);

	}

}
