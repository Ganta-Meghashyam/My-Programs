package demo;

import java.util.Scanner;

public class DistanceBtwTwopoints {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("x1=");
		int x1 = sc.nextInt();
		
		System.out.println("x2=");
		int x2 = sc.nextInt();
		
		System.out.println("y1=");
		int y1 = sc.nextInt();
		
		System.out.println("y2=");
		int y2 = sc.nextInt();
		
		double distbtwtwopts = Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		System.out.println(distbtwtwopts);
	}

}
