package demo;

public class IntegerToBinary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 80;
		System.out.println(Integer.toOctalString(n)); //DECIMAL TO OCTAL
		System.out.println(Integer.toBinaryString(n)); //DECIMAL TO BINARY
		System.out.println(Integer.toHexString(n));    //DECIMAL TO HEXA
		
		System.out.println(Integer.parseInt("127" , 8));  //OCTAL TO DECIMAL
		System.out.println(Integer.parseInt("011001001000001" , 2));  //Binary to decimal
		System.out.println(Integer.parseInt("127" , 16));  //Hexa to decimal
		
		

	}

}
