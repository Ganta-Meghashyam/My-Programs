package demo;

import java.util.Scanner;

public class FirstDigitAndLastDigit {
	
	public static int firstDigit(int num) {
		int digit = 0;
		while(num != 0) {
			digit = num % 10;
			num = num / 10;	
	}
		return digit;
	}
	
	public static int secondDigit(int num) {
		
		return num % 10;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your input:");
		int num = sc.nextInt();
		System.out.println("First Digit is:" +firstDigit(num));
		System.out.println("Second Digit is:" +secondDigit(num));

	}

}
