package demo;

public class Sum2DigitNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=73;
		int sum = 0;
		while (n > 0) {
			int digit = n % 10;
			n = n / 10;
			sum += digit;
			
		}


		System.out.println(sum);

	}

}
