package demo;

import java.util.Scanner;

public class SpeedCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Write a Java program to takes the user for a distance (in meters) and the
		 * time was taken (as three numbers: hours, minutes, seconds), and display the
		 * speed, in meters per second, kilometers per hour and miles per hour (hint: 1
		 * mile = 1609 meters).
		 */

		Scanner sc = new Scanner(System.in);
		System.out.println("Distance in metres:");
		double metre = sc.nextDouble();

		System.out.println("hours:");
		int hrs = sc.nextInt();

		System.out.println("minutes:");
		int min = sc.nextInt();

		System.out.println("seconds:");
		int sec = sc.nextInt();

		int totalTimeInSec = hrs * 60 * 60 + min * 60 + sec;
		double totalTimeInHrs = totalTimeInSec / 3600.0;

		double distanceInKmph = metre / 1000.0;
		double distanceInMiles = metre / 1609.0;

		double speedinkmph = distanceInKmph / totalTimeInHrs;
		double speedInMlph = distanceInMiles / totalTimeInHrs;
		double speedInMps = metre / totalTimeInSec;

		System.out.println(speedinkmph + "kmph");
		System.out.println(speedInMps + "mps");
		System.out.println(speedInMlph + "Mlps");

	}

}
