package demo;

public class s {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        System.out.println("GGGGGGGGGGG     M                   M");
	        System.out.println("G               M M               M M");
	        System.out.println("G               M   M            M  M");
	        System.out.println("G      GGGGGG   M     M        M    M");
	        System.out.println("G      G    G   M       M    M      M");
	        System.out.println("G      G    G   M         M         M");
	        System.out.println("GGGGGGGG    G   M                   M");


	}

}
