package demo;

public class AreaOfRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=73;
		int n2=45;
		int area =n1*n2;
		System.out.println("Area of Rectangle is:" +area );

	}

}
