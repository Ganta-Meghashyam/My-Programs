package demo;

import java.util.Scanner;

public class MinutesInYrsDaysHrsMin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
	  Scanner sc =new Scanner(System.in);
      System.out.println("Enter your minutes:");
      int minutes =sc.nextInt();

      int years_to_min=365*24*60;
      int days_to_min = 24*60;
      int hrs_to_min= 60;
      
      int year = minutes/years_to_min;
      int day =(minutes/days_to_min)-(year*365);
      int hr=(minutes/hrs_to_min)-((year*365*24)+(day*24));
      int min = minutes-(year*years_to_min)-(day*(days_to_min))-(hr*hrs_to_min);
      
      System.out.println(year+"years"+ " "+day+"days" + " " +hr+ "hours" + " "+min+"minutes");
      
      
      
	}

}

